function fecharpop(){
    //var pop = getElementById('popup')
    popup.style.opacity ="0"
    popup.style.transition = "0.5s"
}